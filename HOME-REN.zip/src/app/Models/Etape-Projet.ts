export interface EtapeProjet {
    ID: number;
    Titre: string;
    Description: string;
    
  }
  