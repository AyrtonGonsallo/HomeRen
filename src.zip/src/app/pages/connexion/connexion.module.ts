import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConnexioRoutingModule } from './connexion-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ConnexioRoutingModule
  ]
})
export class ConnexioModule { }
