import { Component } from '@angular/core';

@Component({
  selector: 'app-dimensions-pose-electricite',
  templateUrl: './dimensions.component.html',
  styleUrl: '../formulaire-pose-electricite.component.css'
})
export class PoseElectriciteDimensionsComponent {
  
}

