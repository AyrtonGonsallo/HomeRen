export interface CategoriePiece {
    ID: number;
    Titre: string;
    Description: string;
    
  }
  