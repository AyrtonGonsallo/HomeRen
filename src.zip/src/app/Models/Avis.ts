export interface Avis {
    ID: number;
    Utilisateur: string;
    Message: string;
    
  }
  