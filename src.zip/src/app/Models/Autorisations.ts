export interface Autorisation {
    Id: number; // Ajoutez le point d'interrogation pour indiquer que Id est facultatif
    Explications: string;
    Titre: string;
    DateDeCreation: Date; // Ajoutez le point d'interrogation pour indiquer que DateDeCreation est facultatif
  }
  