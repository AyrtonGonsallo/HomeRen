import { Piece } from "./Piece";

export interface Travail {
    ID: number;
    Titre: string;
    Description: string;
    Pieces: Piece[]
  }
  