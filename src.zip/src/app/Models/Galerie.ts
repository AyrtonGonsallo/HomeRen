export interface Galerie {
    ID: number;
    Titre: string;
    Total: string;
    images:[]
  }
  