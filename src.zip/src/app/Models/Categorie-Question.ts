export interface CategorieQuestion {
    ID: number;
    Titre: string;
    Description: string;
    
  }
  