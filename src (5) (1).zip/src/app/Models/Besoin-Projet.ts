export interface BesoinProjet {
    ID: number;
    Titre: string;
    Description: string;
    
  }
  